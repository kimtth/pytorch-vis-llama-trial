__author__ = 'Tony Beltramelli - www.tonybeltramelli.com'

CONTEXT_LENGTH = 48
IMAGE_SIZE = 256
BATCH_SIZE = 64
EPOCHS = 10
STEPS_PER_EPOCH = 72000
